#!/usr/bin/env bash

#!/usr/bin/env bash

sudo certbot -n \
-d turtle411.us-east-1.elasticbeanstalk.com \
--nginx \
--agree-tos \
--email yuto.t1208@gmail.com
