# INTEX---Turtle-Shelter
https://turtle411.us-east-1.elasticbeanstalk.com/ <br>

Admin username: test<br>
Password: test<br>
Password for PGadmin: <br>
